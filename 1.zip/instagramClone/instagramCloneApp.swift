//
//  instagramCloneApp.swift
//  instagramClone
//
//  Created by Rayann chaghla on 21/10/2024.
//

import SwiftUI

@main
struct instagramCloneApp: App {
    var body: some Scene {
        WindowGroup {
            TheTabViews()
        }
    }
}
