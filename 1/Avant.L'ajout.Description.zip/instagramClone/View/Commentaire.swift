//
//  Commentaire.swift
//  instagramClone
//
//  Created by Rayann chaghla on 04/11/2024.
//

import SwiftUI

struct Commentaire: View {
    var body: some View {
        VStack {
            Text("Commentaire")
        }
        .navigationBarTitleDisplayMode(.inline)
        
    }
}

#Preview {
    Commentaire()
}
