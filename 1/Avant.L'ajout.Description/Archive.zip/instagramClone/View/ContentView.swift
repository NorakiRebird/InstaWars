//
//  ContentView.swift
//  instagramClone
//
//  Created by Rayann chaghla on 21/10/2024.
//
import SwiftUI

struct ContentView: View {
    var body: some View {
        HomeView()
    }
}





#Preview {
    ContentView()
}

